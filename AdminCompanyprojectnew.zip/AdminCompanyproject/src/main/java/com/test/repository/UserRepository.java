package com.test.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.entity.Company;
import com.test.entity.User;



public interface UserRepository extends JpaRepository<User,Integer> {
	
	public boolean existsByEmail(String email);
    
	public User findByEmail(String email);
	
    List<User> findById(int id);

	
List<Company> findUserByCompanyId(String id);

}
