package com.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.pojo.Attendence;

public interface AttendenceRepository extends JpaRepository<Attendence,Integer> {



}
