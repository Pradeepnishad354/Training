package com.test.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.test.entity.Company;

@Entity
public class Attendence {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String startDate;
	private String endDate;
	private String title;
	private String description;

	/*
	 * @ManyToOne private Company company;
	 * 
	 * public Company getCompany() { return company; }
	 * 
	 * public void setCompany(Company company) { this.company = company;
	 * 
	 * }
	 * 
	 * public Attendence(int id, String startDate, String endDate, String title,
	 * String description, Company company) { super(); this.id = id; this.startDate
	 * = startDate; this.endDate = endDate; this.title = title; this.description =
	 * description; this.company = company; }
	 */

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Attendence(int id, String startDate, String endDate, String title, String description) {
		super();
		this.id = id;
		this.startDate = startDate;
		this.endDate = endDate;
		this.title = title;
		this.description = description;
	}

	public Attendence() {
		super();
		// TODO Auto-generated constructor stub
	}

}
