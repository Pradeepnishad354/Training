package com.test.controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.test.entity.Company;
import com.test.pojo.Attendence;
import com.test.repository.CompanyRepository;
import com.test.service.attendence.AttendenceService;

@Controller
public class AttendenceController {

	@Autowired
	private AttendenceService attendenceService;

	@Autowired
	private CompanyRepository companyRepository;

	@GetMapping("/addAttendence")
	public String register(Model model) {

		model.addAttribute("attendence", new Attendence());
		return "Attendence/addattendence";
	}

	/*
	 * @PostMapping("/add-process/{id}") public String
	 * addAttendence(@PathVariable("id") int id, @ModelAttribute Attendence
	 * attendence, HttpSession session) {
	 * 
	 * Optional<Company> user = companyRepository.findById(id);
	 * 
	 * if (!user.isPresent()) {
	 * 
	 * throw new UsernameNotFoundException("id" + id); } else {
	 * 
	 * Company userr = user.get();
	 * 
	 * attendence.setCompany(userr);
	 * 
	 * attendenceService.save(attendence);
	 * 
	 * }
	 * 
	 * session.setAttribute("msg", "save attendence Succesfully");
	 * 
	 * return "redirect:/addAttendence"; }
	 */

	@GetMapping("/show")
	public String showAttendence(Model model) {

		model.addAttribute("attendence", attendenceService.getAttendence());
		return "Attendence/showAttendence";

	}

}
