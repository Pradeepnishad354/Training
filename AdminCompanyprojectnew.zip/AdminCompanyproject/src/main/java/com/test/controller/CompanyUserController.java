package com.test.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.test.entity.Company;
import com.test.repository.CompanyRepository;
import com.test.service.CompanyService;


@Controller
public class CompanyUserController {

	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private CompanyRepository companyRepository;
	
	@GetMapping("/userlogin")
	public String login(Model model) {
		
		model.addAttribute("company",new Company());
		return "normal/login";
	}
		
// @ModelAttribute
//	private void UserDetail(Model m,Authentication authentication) {
//				String name = authentication.getName();
//				
//				System.out.println(name);
//	
//		 Company username = companyRepository.findByUsername(name);
//	 
//		m.addAttribute("username",username);
//	
//		
//	}
	
	
	
	
	
@PostMapping("/fetch")	
public  String fetchUser(@ModelAttribute Company company ,Model model) {
	
	Company Username = companyService.findByUsername(company.getUsername());
	
	if(Username !=null && company.getPassword().equals(Username.getPassword())) {
	model.addAttribute("message","Welcome"+Username.getcName());
	
	return "normal/userShow";
}else {
	
	model.addAttribute("message","username or password incorrect");
	return "normal/welcome";
	
}
	
}		
	}
	

	
	
	
	
	
	
	
	
