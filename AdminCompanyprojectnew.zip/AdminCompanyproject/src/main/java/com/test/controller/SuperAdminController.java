package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.test.admin.repository.SuperAdminRepository;
import com.test.pojo.SuperAdmin;

@Controller
public class SuperAdminController {
	
	@Autowired
	private SuperAdminRepository superAdminRepository;
	
	
	@GetMapping("/adminlogin")
	public String admin() {
		
		
		return "Admin/adminlogin";
	}

	
	@PostMapping("/fetchAdmin")	
	public  String fetchUser(@ModelAttribute SuperAdmin superAdmin ,Model model) {
		
		SuperAdmin admin = superAdminRepository.findByUsername(superAdmin.getUsername());
		
		if(admin !=null && superAdmin.getPassword().equals(admin.getPassword())) {
			
			return "Admin/ShowAdmin";
		}else {
			
			return "Admin/error";
		}
		
		
	 
}
}