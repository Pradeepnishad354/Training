package com.test.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.entity.Company;
import com.test.repository.CompanyRepository;
@Service
public class CompanyServiceImpl implements CompanyService{

	@Autowired
	private CompanyRepository companyRepository;
	@Override
	public Company findByUsername(String username) {
		
		return companyRepository.findByUsername(username);
	}
	
	
	
	
	
}
