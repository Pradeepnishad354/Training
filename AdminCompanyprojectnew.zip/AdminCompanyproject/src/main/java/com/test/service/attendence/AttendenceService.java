package com.test.service.attendence;

import java.util.List;

import com.test.pojo.Attendence;

public interface AttendenceService {

	Attendence save(Attendence Attendence);
	
	List<Attendence> getAttendence();
	
	
}
