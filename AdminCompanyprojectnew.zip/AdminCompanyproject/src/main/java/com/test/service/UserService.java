package com.test.service;

import com.test.entity.User;

public interface UserService {

User saveUser(User user);

public boolean checkEmail(String email);


User get(Integer id);
	
	
	
}
