package com.test.service.attendence;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.pojo.Attendence;
import com.test.repository.AttendenceRepository;

@Service
public class AttendenceServiceImpl implements AttendenceService  {

	@Autowired
	private AttendenceRepository  attendenceRepository;

	
	
	@Override
	public Attendence save(Attendence attendence) {


		return attendenceRepository.save(attendence);
	}

	@Override
	public List<Attendence> getAttendence() {
		
		return attendenceRepository.findAll();
	}

	
	
}
