package com.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.test.admin.repository.SuperAdminRepository;
import com.test.pojo.SuperAdmin;

@SpringBootApplication

public class AdminCompanyprojectApplication implements CommandLineRunner {

	@Autowired
	private SuperAdminRepository superAdminRepository;
	
	public static void main(String[] args) {
		SpringApplication.run(AdminCompanyprojectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		superAdminRepository.save(new SuperAdmin("pradeep@gmail.com","12345"));
		superAdminRepository.save(new SuperAdmin("xyz@gmail.com","12345"));
		
		
	}

	
	
}
